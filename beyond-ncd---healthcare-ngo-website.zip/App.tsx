
import React, { Suspense, lazy } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';

// Lazy load pages for performance
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Hypertension = lazy(() => import('./pages/Hypertension'));
const Diabetes = lazy(() => import('./pages/Diabetes'));
const Programs = lazy(() => import('./pages/Programs'));
const Involved = lazy(() => import('./pages/Involved'));
const Leadership = lazy(() => import('./pages/Leadership'));
const Impact = lazy(() => import('./pages/Impact'));
const Contact = lazy(() => import('./pages/Contact'));
const GetHelp = lazy(() => import('./pages/GetHelp'));

const LoadingScreen = () => (
  <div className="h-screen w-full bg-black flex items-center justify-center flex-col gap-4">
    <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
    <span className="text-orange-500 font-black tracking-widest text-sm uppercase">Loading Beyond NCD...</span>
  </div>
);

const App: React.FC = () => {
  return (
    <Router>
      <Layout>
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/hypertension" element={<Hypertension />} />
            <Route path="/diabetes" element={<Diabetes />} />
            <Route path="/programs" element={<Programs />} />
            <Route path="/involved" element={<Involved />} />
            <Route path="/team" element={<Leadership />} />
            <Route path="/impact" element={<Impact />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/get-help" element={<GetHelp />} />
            {/* Catch all */}
            <Route path="*" element={<Home />} />
          </Routes>
        </Suspense>
        
        {/* Persistent Closing Message (Optional, could be in Layout or specific pages) */}
        <section className="bg-black py-20 border-t border-zinc-900">
           <div className="container mx-auto px-4 text-center">
              <p className="text-2xl md:text-3xl font-medium text-zinc-400 italic max-w-4xl mx-auto">
                 Beyond NCD believes that <span className="text-orange-500">knowledge saves lives</span>. Together, we can reduce the burden of hypertension and diabetes and build healthier communities.
              </p>
           </div>
        </section>
      </Layout>
    </Router>
  );
};

export default App;
