
import React from 'react';
import { Target, Eye, ShieldCheck, HeartPulse, Star } from 'lucide-react';
import { CORE_VALUES, IMAGES } from '../constants';

const About: React.FC = () => {
  return (
    <div className="bg-black pt-32">
      {/* Header & Story */}
      <section className="container mx-auto px-4 md:px-8 mb-24">
        <h1 className="text-6xl font-black text-white mb-12">Our <span className="text-orange-500">Story</span></h1>
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <div className="aspect-[4/5] rounded-[50px] overflow-hidden border-2 border-zinc-800">
               <img src={IMAGES.team_group} alt="Beyond NCD Team" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" />
            </div>
            <div className="absolute -top-6 -right-6 bg-yellow-500 text-black p-8 rounded-3xl hidden md:block border-4 border-black font-black italic">
              Knowledge Saves Lives
            </div>
          </div>
          <div className="space-y-8">
            <div className="space-y-6 text-gray-400 text-xl leading-relaxed">
              <p>
                Beyond NCD was founded in response to the increasing burden of hypertension and diabetes in Tanzania, especially among underserved communities. 
              </p>
              <p>
                Our founder, <strong className="text-white">Jonathan Bingwa</strong>, saw firsthand the challenges: a lack of awareness, late diagnoses, and limited access to accurate health information.
              </p>
              <p>
                Emphasizing compassionate community care, Beyond NCD was created to bridge this gap, transforming lives through education and early screening services in Mwanza and beyond.
              </p>
            </div>
            <div className="bg-zinc-950 p-10 rounded-3xl border border-zinc-900 border-l-orange-500 border-l-[12px]">
              <h3 className="text-yellow-500 font-bold text-2xl mb-4">The Challenge</h3>
              <ul className="space-y-4 text-white">
                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-orange-500"></span> Severe Lack of Public Awareness</li>
                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-orange-500"></span> High Rates of Late Diagnosis</li>
                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-orange-500"></span> Barriers to Health Information</li>
                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-orange-500"></span> High Treatment Costs for Complications</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="bg-zinc-950 py-32 border-y border-zinc-900">
        <div className="container mx-auto px-4 md:px-8 grid lg:grid-cols-3 gap-12 items-center">
          <div className="lg:col-span-2 grid md:grid-cols-2 gap-12">
            <div className="p-12 bg-black border border-zinc-800 rounded-[40px] relative overflow-hidden group">
              <Eye className="absolute -top-10 -right-10 text-orange-500/5 w-40 h-40" />
              <Target className="text-orange-500 mb-6" size={48} />
              <h2 className="text-3xl font-black text-white mb-6">Our Vision</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                A society where people live healthy, informed lives free from preventable complications of non-communicable diseases.
              </p>
            </div>
            <div className="p-12 bg-black border border-zinc-800 rounded-[40px] relative overflow-hidden group">
              <ShieldCheck className="absolute -top-10 -right-10 text-yellow-500/5 w-40 h-40" />
              <HeartPulse className="text-yellow-500 mb-6" size={48} />
              <h2 className="text-3xl font-black text-white mb-6">Our Mission</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                To educate, support, and empower communities to prevent and manage hypertension and diabetes through community-based education, screenings, and patient support.
              </p>
            </div>
          </div>
          <div className="rounded-[40px] overflow-hidden border-2 border-orange-500/20 shadow-2xl">
             <img src={IMAGES.community} alt="Our Community Work" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-32">
        <div className="container mx-auto px-4 md:px-8 text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black text-white mb-4 italic">Our Core <span className="text-orange-500">Values</span></h2>
          <p className="text-zinc-500">The pillars that guide our daily work and community outreach.</p>
        </div>
        <div className="container mx-auto px-4 md:px-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {CORE_VALUES.map((val, idx) => (
            <div key={idx} className="p-10 bg-zinc-900/30 border border-zinc-800 rounded-3xl hover:bg-orange-500 transition-all duration-500 group">
              <Star className="text-yellow-500 mb-6 group-hover:text-black" size={32} />
              <h4 className="text-xl font-bold text-white mb-4 group-hover:text-black">{val.title}</h4>
              <p className="text-gray-500 group-hover:text-black/80">{val.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;
