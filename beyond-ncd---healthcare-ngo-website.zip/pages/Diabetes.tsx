
import React from 'react';
import { Activity, Droplets, HeartPulse, ClipboardCheck, Apple } from 'lucide-react';

const Diabetes: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-20">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto space-y-20">
          {/* Header */}
          <div className="space-y-6">
            <div className="flex items-center gap-4 text-yellow-500 font-bold uppercase tracking-widest text-sm">
              <span className="h-0.5 w-12 bg-yellow-500"></span> Life Management
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white leading-tight">What is <span className="text-yellow-500 italic">Diabetes?</span></h1>
            <p className="text-xl text-gray-400 leading-relaxed">
              Diabetes is a condition where blood sugar levels are too high because the body either cannot produce enough insulin or cannot effectively use the insulin it makes.
            </p>
          </div>

          {/* Types */}
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { type: "Type 1", desc: "Autoimmune condition where the body stops producing insulin." },
              { type: "Type 2", desc: "Most common type. Body becomes resistant to insulin." },
              { type: "Gestational", desc: "High blood sugar that develops during pregnancy." }
            ].map((item, idx) => (
              <div key={idx} className="bg-zinc-950 p-8 rounded-3xl border-t-4 border-t-yellow-500 border border-zinc-900">
                <h3 className="text-white text-xl font-black mb-4">{item.type}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Symptoms & Management */}
          <div className="bg-zinc-950 p-12 rounded-[40px] border border-zinc-900">
             <div className="grid md:grid-cols-2 gap-16">
               <div className="space-y-8">
                 <h3 className="text-3xl font-black text-white">Common Symptoms</h3>
                 <div className="grid grid-cols-1 gap-4">
                   {[
                     { icon: <Droplets className="text-orange-500" />, text: "Frequent urination" },
                     { icon: <Droplets className="text-orange-500" />, text: "Excessive thirst" },
                     { icon: <Activity className="text-orange-500" />, text: "Unusual fatigue" },
                     { icon: <Activity className="text-orange-500" />, text: "Blurred vision" },
                     { icon: <Activity className="text-orange-500" />, text: "Slow wound healing" }
                   ].map((s, i) => (
                     <div key={i} className="flex items-center gap-4 text-gray-300">
                       {s.icon} <span className="font-medium">{s.text}</span>
                     </div>
                   ))}
                 </div>
               </div>
               <div className="space-y-8">
                 <h3 className="text-3xl font-black text-white">Managing Diabetes</h3>
                 <div className="grid grid-cols-1 gap-6">
                   {[
                     { icon: <Apple size={24} />, title: "Healthy Diet", text: "Focus on balanced nutrition." },
                     { icon: <Activity size={24} />, title: "Regular Activity", text: "Keeps blood sugar stable." },
                     { icon: <ClipboardCheck size={24} />, title: "Regular Checkups", text: "Professional monitoring." }
                   ].map((m, i) => (
                     <div key={i} className="flex gap-4">
                       <div className="p-3 bg-yellow-500 text-black rounded-xl h-fit">{m.icon}</div>
                       <div>
                         <h4 className="text-white font-bold">{m.title}</h4>
                         <p className="text-gray-500 text-sm">{m.text}</p>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Diabetes;
