
import React from 'react';
import { Quote, CheckCircle, TrendingUp, Users } from 'lucide-react';
import { IMAGES } from '../constants';

const Impact: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <h1 className="text-6xl font-black text-white mb-8">Our <span className="text-gradient">Impact</span></h1>
        
        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-8 mb-24">
           {[
             { icon: <Users />, value: "5,000+", label: "People Educated" },
             { icon: <CheckCircle />, value: "1,200+", label: "Free Screenings" },
             { icon: <TrendingUp />, value: "40%", label: "Improved Health-Seeking Behavior" }
           ].map((stat, i) => (
             <div key={i} className="p-12 bg-zinc-950 border border-zinc-900 rounded-[40px] text-center">
               <div className="text-orange-500 flex justify-center mb-4">{stat.icon}</div>
               <div className="text-5xl font-black text-white mb-2">{stat.value}</div>
               <div className="text-zinc-500 uppercase tracking-widest text-sm font-bold">{stat.label}</div>
             </div>
           ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
           <div className="space-y-8">
             <h2 className="text-4xl font-black text-white">Stories from the <span className="text-yellow-500 italic">Field</span></h2>
             <p className="text-gray-400 text-lg leading-relaxed">
               Every screening we perform and every class we teach represents a life that could be saved from preventable complications.
             </p>
             <div className="p-12 bg-zinc-900 border border-zinc-800 rounded-[50px] relative">
                <Quote className="text-orange-500/20 absolute top-8 right-8" size={64} />
                <p className="text-2xl text-white italic font-medium leading-relaxed mb-8">
                  “Before this education, I did not know I had high blood pressure. Now I understand my health better and I am taking steps to live longer for my family.”
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-yellow-500"></div>
                  <div>
                    <h5 className="text-white font-bold">Community Member</h5>
                    <p className="text-zinc-500 text-sm">Mwanza, Tanzania</p>
                  </div>
                </div>
             </div>
           </div>
           <div>
             <img src={IMAGES.community} alt="Impact" className="rounded-[60px] shadow-2xl border-2 border-zinc-800" />
           </div>
        </div>
      </div>
    </div>
  );
};

export default Impact;
