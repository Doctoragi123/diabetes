import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Activity, Heart, Shield, Users, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { BRAND, IMAGES } from '../constants';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const Hero: React.FC = () => (
  <section className="relative h-[100vh] min-h-[700px] flex items-center justify-center overflow-hidden bg-black">
    {/* Animated Background Elements */}
    <motion.div 
      animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }}
      transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      className="absolute top-1/4 -left-20 w-96 h-96 bg-orange-600/20 rounded-full blur-[120px]"
    ></motion.div>
    <motion.div 
      animate={{ scale: [1, 1.3, 1], opacity: [0.05, 0.1, 0.05] }}
      transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      className="absolute bottom-1/4 -right-20 w-96 h-96 bg-yellow-600/10 rounded-full blur-[120px]"
    ></motion.div>

    <div className="container mx-auto px-4 md:px-8 flex flex-col lg:flex-row items-center gap-12 z-10">
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="flex-1 space-y-8 text-center lg:text-left"
      >
        <motion.div 
          variants={itemVariants}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-sm font-semibold uppercase tracking-wider"
        >
          <Sparkles size={16} /> Community Health Leader in Mwanza
        </motion.div>
        
        <motion.h1 
          variants={itemVariants}
          className="text-5xl lg:text-7xl font-black text-white leading-tight"
        >
          Empowering Communities to <span className="text-gradient">Prevent & Manage</span> NCDs
        </motion.h1>
        
        <motion.p 
          variants={itemVariants}
          className="text-xl text-gray-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed"
        >
          Beyond NCD is dedicated to reducing the burden of hypertension and diabetes in Tanzania through education, early detection, and patient-centered support.
        </motion.p>

        <motion.div
           variants={itemVariants}
           className="p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl inline-block italic text-yellow-400 font-medium"
        >
           “We believe that no one should suffer or die from preventable complications of non-communicable diseases.”
        </motion.div>

        <motion.div 
          variants={itemVariants}
          className="flex flex-wrap gap-4 justify-center lg:justify-start"
        >
          <Link to="/hypertension" className="group bg-orange-500 hover:bg-orange-600 text-black font-bold px-8 py-4 rounded-full flex items-center gap-2 transition-all shadow-xl shadow-orange-500/30">
            Learn About Hypertension <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link to="/diabetes" className="group border-2 border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black font-bold px-8 py-4 rounded-full flex items-center gap-2 transition-all">
            Learn About Diabetes <Activity size={20} />
          </Link>
        </motion.div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="flex-1 relative w-full h-[450px] lg:h-[600px]"
      >
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ duration: 0.4 }}
          className="absolute top-0 right-0 w-[85%] h-[85%] rounded-[40px] overflow-hidden border-4 border-zinc-900 shadow-2xl z-20"
        >
          <img src={IMAGES.outreach} alt="Beyond NCD Healthcare" className="w-full h-full object-cover" />
        </motion.div>
        <motion.div 
          whileHover={{ scale: 1.05, zIndex: 40 }}
          transition={{ duration: 0.4 }}
          className="absolute bottom-0 left-0 w-[60%] h-[60%] rounded-[30px] overflow-hidden border-8 border-black shadow-2xl z-30"
        >
          <img src={IMAGES.community} alt="Community Support" className="w-full h-full object-cover" />
        </motion.div>
      </motion.div>
    </div>
  </section>
);

const WhoWeAre: React.FC = () => (
  <section className="py-32 bg-zinc-950">
    <div className="container mx-auto px-4 md:px-8">
      <div className="grid lg:grid-cols-2 gap-20 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          <div className="w-20 h-1 bg-gradient-to-r from-orange-500 to-yellow-500"></div>
          <h2 className="text-4xl md:text-5xl font-black text-white">The Challenge of <span className="text-orange-500 italic">"Silent"</span> Diseases</h2>
          <div className="space-y-6 text-gray-400 text-lg leading-relaxed">
            <p>
              Hypertension and diabetes are often called <strong className="text-white">“silent diseases”</strong> because people live with them unknowingly until dangerous complications occur.
            </p>
            <p>
              Beyond NCD exists to change this reality. We believe that through education and early intervention, we can save thousands of lives in Mwanza and across Tanzania.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {[
              { icon: <Activity className="text-orange-500" />, title: "Screening Services", text: "Regular checkups to catch issues early." },
              { icon: <Shield className="text-yellow-500" />, title: "Lifestyle Guidance", text: "Practical tips for healthier living." },
              { icon: <Users className="text-orange-500" />, title: "Community Support", text: "Emotional and peer-led counseling." },
              { icon: <Heart className="text-yellow-500" />, title: "Education", text: "Accurate, accessible health knowledge." }
            ].map((item, idx) => (
              <motion.div 
                key={idx} 
                whileHover={{ y: -5 }}
                className="p-6 bg-zinc-900/50 border border-zinc-800 rounded-2xl hover:border-orange-500/50 transition-colors group"
              >
                <div className="mb-4 transform group-hover:scale-110 transition-transform">{item.icon}</div>
                <h4 className="text-white font-bold mb-2">{item.title}</h4>
                <p className="text-gray-500 text-sm">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="aspect-square rounded-[60px] overflow-hidden border-2 border-orange-500/20">
             <img src={IMAGES.team_pro} alt="Beyond NCD Team" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" />
          </div>
          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="absolute -bottom-10 -right-10 bg-orange-500 text-black p-12 rounded-3xl hidden md:block"
          >
            <p className="text-5xl font-black">100%</p>
            <p className="font-bold text-sm uppercase tracking-widest mt-2">Community Focused</p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  </section>
);

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <WhoWeAre />
    </>
  );
};

export default Home;