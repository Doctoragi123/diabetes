
import React from 'react';
import { Activity, AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';

const Hypertension: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-20">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto space-y-20">
          {/* Intro */}
          <div className="space-y-6">
            <div className="flex items-center gap-4 text-orange-500 font-bold uppercase tracking-widest text-sm">
              <span className="h-0.5 w-12 bg-orange-500"></span> Health Education
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white leading-tight">What is <span className="text-orange-500">Hypertension?</span></h1>
            <p className="text-xl text-gray-400 leading-relaxed">
              Hypertension, commonly known as high blood pressure, occurs when the pressure of blood flowing through your arteries remains consistently high. It often has no warning signs, which is why it's critical to screen regularly.
            </p>
          </div>

          {/* Dangers */}
          <div className="bg-zinc-950 p-12 rounded-[40px] border border-zinc-900 shadow-2xl">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/3">
                <AlertTriangle size={64} className="text-yellow-500 mb-6" />
                <h3 className="text-3xl font-black text-white">Why It Is <span className="text-orange-500 italic">Dangerous</span></h3>
              </div>
              <div className="md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-8">
                {[
                  { title: "Stroke", desc: "Blocked or burst vessels in the brain." },
                  { title: "Heart Failure", desc: "Heart becomes too weak or stiff to pump." },
                  { title: "Kidney Failure", desc: "High pressure damages delicate filters." },
                  { title: "Vision Loss", desc: "Damage to the blood vessels in the eyes." }
                ].map((item, idx) => (
                  <div key={idx} className="space-y-2">
                    <h4 className="text-white font-bold text-lg">{item.title}</h4>
                    <p className="text-gray-500 text-sm">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Risk Factors & Prevention */}
          <div className="grid md:grid-cols-2 gap-12">
            <div className="bg-zinc-900/50 p-10 rounded-3xl border border-zinc-800">
              <h3 className="text-2xl font-black text-white mb-8 border-b border-zinc-800 pb-4">Common Risk Factors</h3>
              <ul className="space-y-4">
                {["High salt intake", "Physical inactivity", "Persistent stress", "Overweight and obesity", "Alcohol and smoking", "Family history"].map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-400 italic">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span> {f}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-zinc-900/50 p-10 rounded-3xl border border-zinc-800">
              <h3 className="text-2xl font-black text-white mb-8 border-b border-zinc-800 pb-4">Prevention & Control</h3>
              <ul className="space-y-4">
                {[
                  "Reduce salt and processed foods",
                  "Stay physically active (30 mins a day)",
                  "Maintain a healthy weight",
                  "Measure blood pressure regularly",
                  "Take medication as prescribed"
                ].map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-white font-medium">
                    <CheckCircle2 size={18} className="text-yellow-500 shrink-0" /> {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hypertension;
