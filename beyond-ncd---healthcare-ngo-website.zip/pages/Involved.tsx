
import React from 'react';
import { Heart, Users, Handshake, Mail, UserPlus, GraduationCap } from 'lucide-react';
import { IMAGES } from '../constants';

const Involved: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-10">
            <h1 className="text-6xl font-black text-white">Make a <span className="text-orange-500 italic">Difference</span> With Us</h1>
            <p className="text-xl text-gray-400 leading-relaxed">
              We believe in collective action. Whether you are a healthcare professional or a passionate community member, there is a place for you at Beyond NCD.
            </p>
            
            <div className="p-8 bg-zinc-950 rounded-[30px] border border-zinc-900 border-l-yellow-500 border-l-[10px]">
               <h3 className="text-white text-2xl font-black mb-6">Volunteer With Us</h3>
               <p className="text-gray-500 mb-8">We warmly welcome professionals and students who want to give back to the community.</p>
               <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: <Heart className="text-orange-500" />, label: "Doctors" },
                    { icon: <Users className="text-yellow-500" />, label: "Nurses" },
                    { icon: <GraduationCap className="text-orange-500" />, label: "Med Students" },
                    { icon: <UserPlus className="text-yellow-500" />, label: "General Volunteers" }
                  ].map((role, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-4 bg-zinc-900 rounded-xl">
                      {role.icon} <span className="text-white font-bold">{role.label}</span>
                    </div>
                  ))}
               </div>
            </div>

            <div className="text-3xl font-black text-white italic">
               “Together, we <span className="text-orange-500">can</span> make a difference.”
            </div>
          </div>

          <div className="space-y-12">
            <div className="bg-zinc-900/50 p-12 rounded-[50px] border border-zinc-800">
               <Handshake size={48} className="text-yellow-500 mb-6" />
               <h2 className="text-3xl font-black text-white mb-6">Partnerships & Support</h2>
               <p className="text-gray-400 mb-8 leading-relaxed">
                 We collaborate with health institutions, international NGOs, and community leaders to scale our impact. Let's work together to build healthier communities in Tanzania.
               </p>
               <button className="w-full bg-orange-500 hover:bg-orange-600 text-black font-black py-4 rounded-full text-lg transition-all shadow-xl shadow-orange-500/20">
                 Partner With Beyond NCD
               </button>
            </div>
            
            <img src={IMAGES.team_group} alt="Beyond NCD Volunteers" className="w-full rounded-[40px] grayscale hover:grayscale-0 transition-all duration-700" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Involved;
