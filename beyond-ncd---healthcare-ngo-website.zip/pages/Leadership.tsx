
import React from 'react';
import { Linkedin, Mail, Heart } from 'lucide-react';
import { BRAND, IMAGES } from '../constants';

const Leadership: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <h1 className="text-6xl font-black text-white mb-24">Our <span className="text-yellow-500">Team</span></h1>
        
        {/* CEO */}
        <div className="grid lg:grid-cols-2 gap-20 items-center mb-40">
           <div className="relative group">
              <div className="absolute -inset-4 bg-orange-500/20 rounded-[40px] blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <img 
                src={IMAGES.team_pro} 
                alt={BRAND.founder} 
                className="w-full aspect-[4/5] object-cover rounded-[40px] relative border-2 border-zinc-800"
              />
              <div className="absolute bottom-6 left-6 right-6 bg-black/80 backdrop-blur-md p-6 rounded-2xl border border-white/10">
                 <h3 className="text-2xl font-black text-white">{BRAND.founder}</h3>
                 <p className="text-orange-500 font-bold uppercase tracking-widest text-xs">Founder & CEO</p>
              </div>
           </div>
           <div className="space-y-8">
             <div className="w-20 h-1 bg-yellow-500"></div>
             <h2 className="text-4xl font-black text-white italic">A Passionate <span className="text-orange-500">Advocate</span></h2>
             <p className="text-xl text-gray-400 leading-relaxed">
               Jonathan Bingwa is a dedicated health advocate driven by the vision of a healthier Tanzania. His work focuses on improving community awareness and ensuring that everyone, regardless of their background, has access to quality care for non-communicable diseases.
             </p>
             <p className="text-gray-500">
               Under his leadership, Beyond NCD has grown from a local initiative in Mwanza into a robust community organization reaching thousands of individuals with life-saving information.
             </p>
             <div className="flex gap-4">
               <button className="p-4 bg-zinc-900 text-white rounded-full hover:bg-orange-500 hover:text-black transition-all"><Linkedin size={24} /></button>
               <button className="p-4 bg-zinc-900 text-white rounded-full hover:bg-orange-500 hover:text-black transition-all"><Mail size={24} /></button>
             </div>
           </div>
        </div>

        {/* Other Team Members */}
        <div>
           <h2 className="text-3xl font-black text-white mb-12 flex items-center gap-4">
             The <span className="text-orange-500">Beyond NCD</span> Family <Heart size={28} className="text-orange-500" fill="currentColor" />
           </h2>
           <div className="grid md:grid-cols-2 gap-12">
             {[
               { image: IMAGES.team_group, role: "Clinical Team", desc: "A committed team of healthcare professionals dedicated to screening and counseling." },
               { image: IMAGES.outreach, role: "Community Outreach", desc: "Health workers and volunteers bringing education directly to people's doorsteps." }
             ].map((member, idx) => (
               <div key={idx} className="space-y-6">
                 <img src={member.image} alt={member.role} className="w-full h-80 object-cover rounded-3xl grayscale hover:grayscale-0 transition-all duration-500" />
                 <h4 className="text-2xl font-bold text-white italic">{member.role}</h4>
                 <p className="text-gray-500 leading-relaxed">{member.desc}</p>
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Leadership;
