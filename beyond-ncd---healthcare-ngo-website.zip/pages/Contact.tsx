
import React from 'react';
import { Phone, MapPin, Mail, MessageSquare, Send } from 'lucide-react';
import { BRAND } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid lg:grid-cols-2 gap-20">
          <div className="space-y-12">
            <div>
              <h1 className="text-6xl font-black text-white mb-6">Let's <span className="text-gradient">Connect</span></h1>
              <p className="text-xl text-zinc-400">Knowledge saves lives. Get in touch for support, partnerships, or more information.</p>
            </div>
            
            <div className="space-y-8">
              <div className="flex gap-6 items-center">
                <div className="w-16 h-16 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500">
                  <MapPin size={32} />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Location</h4>
                  <p className="text-zinc-500">{BRAND.location}</p>
                </div>
              </div>
              
              <div className="flex gap-6 items-center">
                <div className="w-16 h-16 rounded-2xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-yellow-500">
                  <Phone size={32} />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Phone</h4>
                  <p className="text-zinc-500">{BRAND.phone}</p>
                </div>
              </div>
              
              <div className="flex gap-6 items-center">
                <div className="w-16 h-16 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500">
                  <Mail size={32} />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Email</h4>
                  <p className="text-zinc-500">{BRAND.email}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-zinc-950 p-10 md:p-16 rounded-[60px] border border-zinc-900 shadow-2xl">
            <h3 className="text-3xl font-black text-white mb-10 flex items-center gap-4">
              Send a <span className="text-orange-500">Message</span> <MessageSquare className="text-orange-500" />
            </h3>
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-zinc-500 uppercase tracking-widest">Full Name</label>
                  <input type="text" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-orange-500 transition-colors" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-zinc-500 uppercase tracking-widest">Email</label>
                  <input type="email" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-orange-500 transition-colors" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-zinc-500 uppercase tracking-widest">Subject</label>
                <input type="text" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-orange-500 transition-colors" placeholder="Inquiry about..." />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-zinc-500 uppercase tracking-widest">Message</label>
                <textarea rows={5} className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-orange-500 transition-colors" placeholder="How can we help?"></textarea>
              </div>
              <button className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 text-black font-black py-5 rounded-xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-transform">
                SEND MESSAGE <Send size={20} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
