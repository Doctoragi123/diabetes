
import React from 'react';
import { Phone, HeartPulse, UserCheck, ShieldCheck, MapPin } from 'lucide-react';
import { BRAND } from '../constants';

const GetHelp: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-6xl font-black text-white mb-8">We Are <span className="text-orange-500 italic">Here</span> For You</h1>
          <p className="text-2xl text-zinc-400 mb-20 leading-relaxed">
            Living with hypertension or diabetes can be challenging, but you don't have to face it alone. Beyond NCD is here to provide the support and guidance you need.
          </p>

          <div className="grid md:grid-cols-2 gap-12 mb-20">
             {[
               { icon: <HeartPulse className="text-orange-500" />, title: "Education & Counseling", text: "Personalized advice for managing your condition." },
               { icon: <UserCheck className="text-yellow-500" />, title: "Screening & Detection", text: "Accurate checks for blood pressure and sugar levels." },
               { icon: <ShieldCheck className="text-orange-500" />, title: "Lifestyle Guidance", text: "Nutrition plans and exercise routines for NCD management." },
               { icon: <MapPin className="text-yellow-500" />, title: "Referral Support", text: "We help connect you to trusted healthcare facilities." }
             ].map((service, i) => (
               <div key={i} className="flex gap-6 p-8 bg-zinc-950 border border-zinc-900 rounded-[30px]">
                 <div className="shrink-0">{service.icon}</div>
                 <div>
                   <h4 className="text-white text-xl font-bold mb-2">{service.title}</h4>
                   <p className="text-zinc-500 text-sm leading-relaxed">{service.text}</p>
                 </div>
               </div>
             ))}
          </div>

          <div className="bg-orange-500 p-12 md:p-16 rounded-[60px] text-black text-center space-y-8 shadow-2xl shadow-orange-500/20">
             <h2 className="text-4xl font-black">Need Urgent Support?</h2>
             <p className="text-xl font-medium max-w-2xl mx-auto">Contact us directly for counseling or to find the nearest screening event in Mwanza.</p>
             <div className="flex flex-col md:flex-row items-center justify-center gap-8">
                <div className="flex items-center gap-4 text-3xl font-black">
                   <Phone size={40} /> {BRAND.phone}
                </div>
                <div className="h-10 w-px bg-black/20 hidden md:block"></div>
                <div className="flex items-center gap-4 text-3xl font-black uppercase tracking-tight">
                   MWANZA, TANZANIA
                </div>
             </div>
             <p className="pt-4 font-bold italic">“Knowledge saves lives. Don't wait until complications occur.”</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetHelp;
