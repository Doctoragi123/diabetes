import React from 'react';
import { Users, Search, HeartPulse, Sprout, BookOpen, MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15
    }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const Programs: React.FC = () => {
  return (
    <div className="bg-black pt-32 pb-32">
      <div className="container mx-auto px-4 md:px-8">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-6xl font-black text-white mb-20 text-center"
        >
          Our <span className="text-orange-500">Programs</span>
        </motion.h1>
        
        {/* Current Programs */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-32"
        >
          {[
            { icon: <Users size={40} />, title: "Health Education", desc: "Group sessions in communities across Mwanza to spread awareness." },
            { icon: <Search size={40} />, title: "Free Screenings", desc: "Regular blood pressure and blood sugar testing camps." },
            { icon: <MessageCircle size={40} />, title: "Patient Counseling", desc: "One-on-one sessions for emotional and lifestyle guidance." },
            { icon: <HeartPulse size={40} />, title: "Lifestyle Education", desc: "Practical guidance on diet, exercise, and stress management." },
            { icon: <BookOpen size={40} />, title: "Awareness Campaigns", desc: "Media and digital outreach to inform the wider public." }
          ].map((item, idx) => (
            <motion.div 
              key={idx} 
              variants={cardVariants}
              whileHover={{ y: -10, borderColor: "rgba(249, 115, 22, 0.4)" }}
              className="p-10 bg-zinc-950 border border-zinc-900 rounded-[30px] transition-all group"
            >
              <div className="text-orange-500 mb-6 transform group-hover:-translate-y-2 transition-transform">{item.icon}</div>
              <h3 className="text-2xl font-black text-white mb-4">{item.title}</h3>
              <p className="text-gray-500 leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Future Goals */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-orange-500/5 to-yellow-500/5 p-12 md:p-20 rounded-[60px] border border-zinc-800"
        >
           <div className="max-w-4xl mx-auto text-center space-y-12">
             <div className="inline-flex items-center gap-2 px-6 py-2 bg-yellow-500 text-black font-black rounded-full text-sm">
                <Sprout size={18} /> THE FUTURE OF BEYOND NCD
             </div>
             <h2 className="text-4xl md:text-5xl font-black text-white">Expanding Our <span className="text-orange-500">Reach</span></h2>
             <div className="grid sm:grid-cols-2 gap-8 text-left">
               {[
                 "Expand outreach to rural communities in Mwanza Region",
                 "Develop comprehensive Swahili-language materials",
                 "Strengthen partnerships with local healthcare facilities",
                 "Establish long-term patient follow-up programs"
               ].map((goal, idx) => (
                 <motion.div 
                    key={idx} 
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex items-start gap-4"
                  >
                   <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center shrink-0">
                     <span className="text-yellow-500 text-xs font-bold">{idx + 1}</span>
                   </div>
                   <p className="text-gray-300 font-medium pt-1">{goal}</p>
                 </motion.div>
               ))}
             </div>
           </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Programs;