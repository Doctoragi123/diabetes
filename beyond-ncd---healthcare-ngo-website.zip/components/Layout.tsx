
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
// Added Mail to the imports from lucide-react
import { Menu, X, Phone, MapPin, Heart, ArrowRight, Mail } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { BRAND, NAV_ITEMS } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black/90 backdrop-blur-md py-3 shadow-lg shadow-orange-900/10' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="p-1.5 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-lg group-hover:rotate-12 transition-transform">
            <Heart className="text-black w-6 h-6" fill="black" />
          </div>
          <div>
            <span className="text-xl font-extrabold text-white tracking-tight">BEYOND <span className="text-orange-500">NCD</span></span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex gap-8 items-center">
          {NAV_ITEMS.map((item) => (
            <Link 
              key={item.path} 
              to={item.path}
              className={`text-sm font-medium transition-colors hover:text-orange-500 ${location.pathname === item.path ? 'text-orange-500' : 'text-gray-300'}`}
            >
              {item.label}
            </Link>
          ))}
          <Link to="/get-help" className="bg-gradient-to-r from-orange-500 to-yellow-500 text-black px-5 py-2 rounded-full font-bold text-sm hover:scale-105 transition-transform shadow-lg shadow-orange-500/20">
            GET HELP
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button className="lg:hidden text-orange-500" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-black border-t border-gray-800"
          >
            <div className="flex flex-col p-6 gap-4">
              {NAV_ITEMS.map((item) => (
                <Link 
                  key={item.path} 
                  to={item.path} 
                  className="text-lg text-white hover:text-orange-500"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Link 
                to="/get-help" 
                className="bg-orange-500 text-black py-3 rounded-lg text-center font-bold"
                onClick={() => setIsOpen(false)}
              >
                GET HELP
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer: React.FC = () => (
  <footer className="bg-zinc-950 border-t border-zinc-900 pt-20 pb-10">
    <div className="container mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Heart className="text-orange-500 w-8 h-8" fill="currentColor" />
          <span className="text-2xl font-black text-white">BEYOND <span className="text-orange-500">NCD</span></span>
        </div>
        <p className="text-gray-400 text-sm leading-relaxed">
          {BRAND.tagline}. Based in {BRAND.location}.
        </p>
        <div className="flex gap-4">
          <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-black transition-all cursor-pointer">
            <span className="font-bold">f</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-black transition-all cursor-pointer">
            <span className="font-bold">in</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-black transition-all cursor-pointer">
            <span className="font-bold">ig</span>
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-white font-bold mb-6 border-l-4 border-orange-500 pl-4">QUICK LINKS</h4>
        <ul className="space-y-4 text-gray-400 text-sm">
          {NAV_ITEMS.map(item => (
            <li key={item.path}><Link to={item.path} className="hover:text-orange-500 transition-colors">{item.label}</Link></li>
          ))}
        </ul>
      </div>

      <div>
        <h4 className="text-white font-bold mb-6 border-l-4 border-yellow-500 pl-4">CONTACT US</h4>
        <ul className="space-y-4 text-gray-400 text-sm">
          <li className="flex items-center gap-3"><MapPin className="text-orange-500 shrink-0" size={18} /> {BRAND.location}</li>
          <li className="flex items-center gap-3"><Phone className="text-orange-500 shrink-0" size={18} /> {BRAND.phone}</li>
          <li className="flex items-center gap-3"><Mail className="text-orange-500 shrink-0" size={18} /> {BRAND.email}</li>
        </ul>
      </div>

      <div>
        <h4 className="text-white font-bold mb-6 border-l-4 border-orange-500 pl-4">NEWSLETTER</h4>
        <p className="text-gray-400 text-sm mb-4">Stay updated with our community health campaigns.</p>
        <form className="flex">
          <input type="email" placeholder="Email address" className="bg-zinc-900 border border-zinc-800 px-4 py-2 text-sm text-white rounded-l-md focus:outline-none focus:border-orange-500 w-full" />
          <button className="bg-orange-500 text-black px-4 py-2 rounded-r-md hover:bg-orange-600 transition-colors">
            <ArrowRight size={18} />
          </button>
        </form>
      </div>
    </div>
    
    <div className="container mx-auto px-4 mt-20 pt-8 border-t border-zinc-900 text-center text-zinc-600 text-xs">
      <p>&copy; {new Date().getFullYear()} Beyond NCD. All Rights Reserved. Knowledge Saves Lives.</p>
    </div>
  </footer>
);

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Navbar />
      <main className="flex-grow pt-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.4 }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
};
