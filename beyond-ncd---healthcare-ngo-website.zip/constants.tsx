
import React from 'react';
import { HeartPulse, Droplets, ShieldCheck, Users, Info, HelpCircle, Phone, Mail, MapPin, Award, Activity } from 'lucide-react';
import { NavItem, Value } from './types';

export const BRAND = {
  name: "Beyond NCD",
  tagline: "Transforming Lives Beyond Non-Communicable Diseases",
  location: "Mwanza, Tanzania",
  phone: "0735 567 890",
  email: "info@beyondncd.org",
  founder: "Jonathan Bingwa"
};

export const NAV_ITEMS: NavItem[] = [
  { label: "Home", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Hypertension", path: "/hypertension" },
  { label: "Diabetes", path: "/diabetes" },
  { label: "Programs", path: "/programs" },
  { label: "Impact", path: "/impact" },
  { label: "Get Involved", path: "/involved" },
  { label: "Contact", path: "/contact" }
];

export const CORE_VALUES: Value[] = [
  { title: "Compassion", description: "Providing care with empathy and understanding for those we serve." },
  { title: "Community Empowerment", description: "Enabling individuals to take charge of their own health outcomes." },
  { title: "Health Equity", description: "Striving for accessible care regardless of socio-economic status." },
  { title: "Integrity", description: "Transparency and honesty in all our operations and communications." },
  { title: "Evidence-Based Education", description: "Ensuring all health information shared is scientifically grounded." }
];

export const IMAGES = {
  // 1768654593289 - Outreach Action
  outreach: "https://ik.imagekit.io/Doctoragi123/1768654593289.jpg?updatedAt=1768654746843",
  // 1768654297839 - Community Interaction
  community: "https://ik.imagekit.io/Doctoragi123/1768654297839.jpg?updatedAt=1768654746877",
  // 1768654287251 - Professional Team 1
  team_pro: "https://ik.imagekit.io/Doctoragi123/1768654287251.jpg?updatedAt=1768654746934",
  // 1768654272323 - Group Team 2
  team_group: "https://ik.imagekit.io/Doctoragi123/1768654272323.jpg?updatedAt=1768654746826"
};
